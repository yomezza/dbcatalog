CatalogDB 0.15.0

Windows: распакуйте архив и запустите CatalogDB.exe; нужен Edge WebView2.
Linux: запустите ./CatalogDB в графической сессии; glibc 2.41+, GTK 3 и WebKitGTK 4.1.
Для работы нужен доступ к PostgreSQL. Схема остаётся 016.

Печать одного объекта: кнопка «Печать в PDF» в карточке или меню.
Печать подборки: отметьте БД и нажмите «Печать выбранных БД».
В параметрах доступны подробный и краткий виды и флажок политик РК.
Краткий вид: один объект на странице A4. Если полный текст не помещается, выберите подробный вид.
До 500 БД в одном файле. PDF остаётся в «Загрузках» при отмене сохранения копии.

Руководство: https://github.com/yomezza/dbcatalog/wiki/Printing-to-PDF
Проверки: https://github.com/yomezza/dbcatalog/blob/catalogdb-go/docs/validation-0.15.0.md
Релизы: https://github.com/yomezza/dbcatalog/releases
