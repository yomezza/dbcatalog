CatalogDB 0.13.1

Windows: распакуйте архив, запустите CatalogDB.exe. Нужен Edge WebView2.
Linux: распакуйте архив, запустите ./CatalogDB в графической сессии.
Нужны glibc 2.41+, GTK 3, WebKitGTK 4.1; для секретов — Secret Service.

Подключитесь к доступной PostgreSQL-базе и схеме, затем войдите в каталог.
Перед обновлением рабочего каталога сохраните резервную копию PostgreSQL.

Руководство: https://github.com/yomezza/dbcatalog/wiki
Выпуск: https://github.com/yomezza/dbcatalog/releases/tag/v0.13.1
Проверки: https://github.com/yomezza/dbcatalog/blob/v0.13.1/docs/validation-0.13.1.md

Ключи, пароли и рабочие данные в архив не включены.
