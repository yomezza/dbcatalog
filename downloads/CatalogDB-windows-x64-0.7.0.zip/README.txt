﻿CatalogDB 0.7.0 — Windows x64 (предварительная сборка)

Распакуйте архив полностью и запустите CatalogDB.exe.
Нужны Windows 10/11 x64, Microsoft Edge WebView2 Runtime и доступ к PostgreSQL.
При подключении автоматически применяется миграция 008 выбранной схемы.
По умолчанию схема dbcatalog; можно указать собственную.

Новое:
- Выбор БД, массовая правка ответственного/организации/состояния/работы АБД
  с таблицей «Было / Станет» и отдельным подтверждением.
- Комбинированные фильтры каталога и личные именованные наборы.
- Раздел «Качество данных» с переходами к карточкам.
- Раздел «Удалённые» для администратора: объект или ветвь, проверка конфликтов,
  сохранение UUID и продолжение номеров версий.
- Импорт политик РК из 28 колонок: явные параметры, исправления отдельных строк,
  предпросмотр назначения/замены и отдельное подтверждение.
- Экспорт результата поиска/фильтра или выбранных БД через «Загрузки».

Проверки: 54 Go-теста с PostgreSQL и race detector, go vet, 11 модульных тестов
интерфейса, 31 браузерный сценарий; Windows EXE и native test binary скомпилированы.
Два теста частного XLS пропущены; реальные записи пользователя не импортировались.
Проверка реального запуска Windows, установщика, Credential Manager, RDP/SSH
и системных диалогов здесь НЕ выполнена: облачная среда работает под Linux.
Для Windows подготовлены job GitHub Actions и packaging/windows-smoke.ps1.
ZIP содержит переносимый EXE; установщик собирается отдельно на Windows.

Исходники и инструкции:
https://github.com/yomezza/test/tree/catalogdb-go
https://github.com/yomezza/test/blob/catalogdb-go/README.md
https://github.com/yomezza/test/blob/catalogdb-go/docs/catalog-workflows.md
https://github.com/yomezza/test/blob/catalogdb-go/docs/windows-release-check.md

Для принудительного открытия настроек:
CatalogDB.exe --setup-connection

Настройки: %LOCALAPPDATA%\DBCatalog\connection.json
Пароль PostgreSQL — Windows Credential Manager, не файл настроек.
