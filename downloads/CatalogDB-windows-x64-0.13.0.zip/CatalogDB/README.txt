CatalogDB 0.13.0 — Windows x64

Распакуйте весь архив в отдельную папку и запустите CatalogDB.exe.
Нужен Microsoft Edge WebView2 Runtime.

Укажите доступную PostgreSQL-базу, схему и PostgreSQL-учётную запись.
Пустое имя схемы означает dbcatalog. Затем войдите пользователем каталога.
Первую учётную запись новой схемы создаёт администратор.
Перед обновлением рабочего каталога сделайте резервную копию PostgreSQL.

Руководство: https://github.com/yomezza/dbcatalog/wiki
Проверки: https://github.com/yomezza/dbcatalog/blob/v0.13.0/docs/validation-0.13.0.md
Выпуск: https://github.com/yomezza/dbcatalog/releases/tag/v0.13.0

Закрытые ключи, пароли и рабочие данные в архив не включены.
