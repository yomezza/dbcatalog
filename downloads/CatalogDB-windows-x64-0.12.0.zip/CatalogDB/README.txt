CatalogDB 0.12.0

Windows: распакуйте архив и запустите CatalogDB.exe. Нужен Microsoft Edge WebView2 Runtime.
Linux: распакуйте архив и запустите ./CatalogDB в графической сессии.
Linux-сборка требует glibc 2.41+, GTK 3 и WebKitGTK 4.1.
Нужны реквизиты существующей базы PostgreSQL и учётная запись CatalogDB.

Новое: стрелка рядом с заголовком «Рабочая область» сворачивает панель до иконок.
Повторное нажатие раскрывает её. Подписи доступны в подсказках.
Выбранный вид запоминается на этом компьютере.

Руководство: https://github.com/yomezza/dbcatalog/wiki
Версии: https://github.com/yomezza/dbcatalog/releases
