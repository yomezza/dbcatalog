CatalogDB 0.13.0 — Linux x64

Распакуйте архив, откройте папку CatalogDB и запустите ./CatalogDB
в графической сессии. Нужны glibc 2.41+, GTK 3, WebKitGTK 4.1.
Для сохранения секретов нужен Secret Service (например, GNOME Keyring).

Настройка PostgreSQL и вход: https://github.com/yomezza/dbcatalog/wiki/Getting-started
Linux: https://github.com/yomezza/dbcatalog/blob/v0.13.0/docs/linux.md
Проверки: https://github.com/yomezza/dbcatalog/blob/v0.13.0/docs/validation-0.13.0.md
Выпуск: https://github.com/yomezza/dbcatalog/releases/tag/v0.13.0

Закрытые ключи, пароли и рабочие данные в архив не включены.
