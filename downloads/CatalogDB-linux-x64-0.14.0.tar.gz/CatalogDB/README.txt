CatalogDB 0.14.0

Windows: распакуйте архив и запустите CatalogDB.exe; нужен Edge WebView2.
Linux: запустите ./CatalogDB в графической сессии; glibc 2.41+, GTK 3, WebKitGTK 4.1.
Для работы нужен доступ к PostgreSQL. Схема 016, новых миграций нет.

PDF: откройте карточку и нажмите «Печать в PDF».
Файл сохраняется в «Загрузки», затем можно сохранить копию через системный диалог.
Демонстрационный PDF содержит только вымышленные данные.

Руководство: https://github.com/yomezza/dbcatalog/wiki/Printing-to-PDF
Проверки: https://github.com/yomezza/dbcatalog/blob/v0.14.0/docs/validation-0.14.0.md
Все версии: https://github.com/yomezza/dbcatalog/releases
